# Dependencies
- Python 3
