# Dream Vacation

With flights going from anywhere to everywhere in these times, deciding a vacation destination has become a nightmarish task. Deciding on a destination has started taking more time than the actual vacation. Our product aims to reduce this mental load on the user, and present him with travel plans curated to his needs, that makes trip selection a child’s play, and the actual trips more worthwhile.

## To operate, use these commands sequentially
`pip3 install --user -r requirements.txt`
`flask run`